Welcome to Just Cause 2: Camtool, 99% fat-free version!
Make sure Just Cause 2 is running, and Rico has spawned, then run Injector.exe.
Make sure that jc2cam-fatfree.dll is in the same folder as Injector.exe!

Controls:
    Noclip:
        Numpad 0:                        Disable noclip
        Numpad .:                        Enable noclip

        Numpad /:                        Disable automatic teleport of Rico (off by default)
        Numpad *:                        Enable automatic teleport of Rico
                                         If you're moving far away, this *needs* to be enabled
                                         otherwise the land Rico is standing on will be unloaded.

        W:                               Forward
        A:                               Left
        D:                               Right
        S:                               Backwards
        Space:                           Upwards
        Left Control:                    Downwards
        R:                               Reset FOV, roll and camera speed

        Shift:                           2x speed
        Mouse-wheel:                     Control speed
        Middle-mouse and vertical drag:  FOV

        Numpad 8:                        Rotates 1 degree upwards
        Numpad 2:                        Rotates 1 degree downwards
        Numpad 4:                        Rotates 1 degree to the left
        Numpad 6:                        Rotates 1 degree to the right

        F3:                              Freeze camera in place (allowing you to control Rico)
        F4:                              Unfreeze camera        

        F7:                              Hide GUI
        F8:                              Restore GUI

        F11:                             Write camera position and angle to log